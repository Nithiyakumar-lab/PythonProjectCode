from robocorp.tasks import task
from robocorp import browser
from RPA.HTTP import HTTP
from RPA.Tables import Tables
from RPA.PDF import PDF
from fpdf import FPDF
from RPA.Archive import Archive
import os

@task
def order_robots_from_RobotSpareBin():
    """
    Orders robots from RobotSpareBin Industries Inc.
    Saves the order HTML receipt as a PDF file.
    Saves the screenshot of the ordered robot.
    Embeds the screenshot of the robot to the PDF receipt.
    Creates ZIP archive of the receipts and the images.
    """
    browser.configure(
        slowmo=200,
    )
    open_robot_order_website()
    close_annoying_modal()
    orders = get_orders()
    for row in orders:
        count = 0
        while True:
            order_status = fill_the_form(row)
            count = count+1
            if order_status == "Yes" or count == 3:
                break
    archive_receipts()


def archive_receipts():
    """Zip the output files"""
    lib = Archive()
    lib.archive_folder_with_zip('output/Files','outputfiles.zip')
            
    
def open_robot_order_website():
    """open the browser and navigate to the website"""
    browser.goto("https://robotsparebinindustries.com/#/robot-order")
    
def close_annoying_modal():
    """Close the prompt"""
    page = browser.page()
    page.click("text=OK")
    
def get_orders():
    """Download the Orders csv file"""    
    http = HTTP()
    http.download(url="https://robotsparebinindustries.com/orders.csv",overwrite=True)
    library = Tables()
    orders_table = library.read_table_from_csv("orders.csv")
    return orders_table
    
def fill_the_form(Order_Details):
    """filling the form with error handling"""
    page = browser.page()
    page.select_option("#head",str(Order_Details["Head"]))
    page.click("id=id-body-" + str(Order_Details["Body"]))
    page.get_by_placeholder("Enter the part number for the legs").fill(str(Order_Details["Legs"]))
    page.fill("#address",str(Order_Details["Address"]))
    page.click("id=order")
    locator = page.locator("#order-completion")
    if locator.is_visible():
        pdf_file1 = store_receipt_as_pdf(str(Order_Details["Order number"]))
        screenshot1=screenshot_robot(str(Order_Details["Order number"]))
        embed_screenshot_to_receipt(screenshot1,pdf_file1)
        page.click("text=Order another robot")
        close_annoying_modal()
        order_completed = "Yes"
        return order_completed
    else:
        order_completed = "No"
        return order_completed
    
    
def store_receipt_as_pdf(order_number):
    """storing the completion receipt"""
    page = browser.page()
    receipts = page.locator("#order-completion").inner_html()
    pdf = PDF()
    pdf.html_to_pdf(receipts,"output/Files/Robot"+ order_number + ".pdf")
    pdf_file_name = "output/Files/Robot"+ order_number + ".pdf"
    return pdf_file_name
    
def screenshot_robot(order_number1):
    """Taking the robot screenshot"""
    page = browser.page()
    page.screenshot(path="output/Files/Robot"+order_number1+".png")
    screenshotpdf("output/Files/Robot"+order_number1+".png",order_number1)
    return "output/Files/Robot"+order_number1+order_number1+".pdf"
    

def screenshotpdf(path,onumber):
    """Saving the screenshot into the pdf"""
    pdfpage = FPDF(unit="pt", format=[1280, 720])
    pdfpage.add_page()
    pdfpage.image(path,x=0,y=0,w=1280,h=720)
    pdfpage.output("output/Files/Robot"+onumber + onumber +".pdf")
    os.remove(path)
    
    
def embed_screenshot_to_receipt(List_files,pdf_file):
    """Adding the robot screenshot to existing pdf file"""
    pdf = PDF()
    pdf.add_files_to_pdf(files=[List_files],target_document=pdf_file,append=True)
    os.remove(List_files)
    
    
    
    